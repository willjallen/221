# Build
Unix - `sh build_makefiles_unix.sh`
Windows - `./build_makefiles_windows.bat`

Executable will be generated in build folder
